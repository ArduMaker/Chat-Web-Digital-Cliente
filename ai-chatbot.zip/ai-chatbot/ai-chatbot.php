<?php
/*
Plugin Name: AI Chatbot Widget
Description: Chat widget DigitalMTX.
Version: 4.0
Author: Ardumaker
*/

add_action('wp_enqueue_scripts', function () {
  $dir = plugin_dir_url(__FILE__) . 'assets/';
  $v   = '4.0';

  wp_enqueue_style(
    'cb-css',
    $dir . 'chatbot.css',
    [],
    $v
  );

  wp_enqueue_script('cb-api', $dir . 'chatbot_api.js', [], $v, true);
  wp_enqueue_script('cb-ui', $dir . 'chatbot_ui.js', ['cb-api'], $v, true);
  wp_enqueue_script('cb-sse', $dir . 'chatbot_sse.js', ['cb-api'], $v, true);
  wp_enqueue_script('cb-app', $dir . 'chatbot.js', ['cb-ui', 'cb-sse'], $v, true);

  // Runtime config for frontend API client.
  wp_localize_script('cb-api', 'DMTX_CHATBOT_CONFIG', [
    'apiBaseUrl' => 'https://apidigitalmtx.arducloud.com',
    'debug' => (defined('WP_DEBUG') && WP_DEBUG),
  ]);
});

add_action('wp_footer', function() {
    ?>
    <button class="cb-btn">💬</button>
    <div class="cb-panel">
        <div class="cb-header">
            <div class="cb-header-info">
                <div class="cb-avatar"></div>
                <div>
                    <div class="cb-title">DigitalMTX Chat</div>
                    <div class="cb-sub">Estamos en línea</div>
                </div>
            </div>
            <button class="cb-close-btn">✖</button>
        </div>
        <div class="cb-body"></div>
        <div class="cb-footer">
            <textarea class="cb-input" placeholder="Escribe aquí..."></textarea>
            <button class="cb-send-btn">▶</button>
        </div>
    </div>
    <?php
});

// chatbot-ui.js — DOM y mensajes
const ChatUI = (function () {
    const ICON_SVG = `<svg fill="#FFFFFF" height="28px" width="28px" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg"><path d="M16 2C8.28 2 2 7.8 2 14.93c0 3.6 1.56 6.86 4.1 9.25L4.5 29.5l5.84-2.6A14.8 14.8 0 0016 27.86c7.72 0 14-5.8 14-12.93S23.72 2 16 2z"/></svg>`;
    const CLOSE_SVG = `<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 4L4 12M4 4l8 8" stroke="white" stroke-width="2" stroke-linecap="round"/></svg>`;
    const SEND_SVG = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M22 2L11 13M22 2L15 22L11 13M22 2L2 9L11 13" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
  
    // ── Criar HTML ──────────────────────────────────────────────────────────────
    function createHTML() {
      const root = document.createElement("div");
      root.innerHTML = `
<button class="cb-btn pulse" aria-label="Abrir chat">${ICON_SVG}</button>
<div class="cb-panel" role="dialog" aria-label="Chat de soporte">
  <div class="cb-header">
    <div class="cb-header-info">
      <div class="cb-avatar">${ICON_SVG}</div>
      <div>
        <div class="cb-title">Asistente digital</div>
        <div class="cb-sub">Soporte instantáneo</div>
        <div class="cb-online"><span class="cb-online-dot"></span> En línea</div>
      </div>
    </div>
    <div class="cb-header-actions">
      <button class="cb-close-btn" aria-label="Cerrar">${CLOSE_SVG}</button>
      <button class="cb-end-btn" id="cb-end-chat" type="button">Finalizar conversación</button>
    </div>
  </div>

  <div id="cb-screen-form" style="flex:1;display:flex;flex-direction:column;overflow:hidden">
    <div class="cb-form">
      <div>
        <div class="cb-form-title">¡Bienvenido! 👋</div>
        <div class="cb-form-sub">Díganos su nombre para poder ayudarle mejor.</div>
      </div>
      <div>
        <label class="cb-label" for="cb-name">Su nombre *</label>
        <input class="cb-field" id="cb-name" type="text" placeholder="Juan García" autocomplete="name" />
      </div>
      <div>
        <label class="cb-label" for="cb-email">Correo electrónico (opcional)</label>
        <input class="cb-field" id="cb-email" type="email" placeholder="juan@ejemplo.com" autocomplete="email" />
      </div>
      <button class="cb-start-btn" id="cb-start">Iniciar conversación</button>
    </div>
  </div>

  <div id="cb-screen-chat" style="display:none;flex:1;flex-direction:column;overflow:hidden;min-height:0">
    <div class="cb-body" id="cb-body"></div>
    <div id="cb-responder-status" style="padding:8px 12px;border-top:1px solid #e2e8f0;font-size:12px;color:#64748b;background:#f8fafc;">
      Asistente virtual respondiendo
    </div>
    <div class="cb-footer">
      <textarea class="cb-input" id="cb-input" placeholder="Escriba su mensaje..." rows="1"></textarea>
      <button class="cb-send-btn" id="cb-send" disabled aria-label="Enviar">${SEND_SVG}</button>
    </div>
  </div>
</div>
      `;
      document.body.appendChild(root);
      return root;
    }
  
    // ── Mensajes ────────────────────────────────────────────────────────────────
    function addUserMessage(body, text) {
      const d = document.createElement("div");
      d.className = "cb-msg cb-user";
      d.innerHTML = `${esc(text)}<span class="cb-msg-time">${time()}</span>`;
      body.appendChild(d);
      scroll(body);
    }
  
    function addBotMessage(body, text, onFirstMessage) {
      const d = document.createElement("div");
      d.className = "cb-msg cb-bot";
      const fmt = esc(text).replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>").replace(/\n/g, "<br>");
      d.innerHTML = `${fmt}<span class="cb-msg-time">${time()}</span>`;
      body.appendChild(d);
  
      if (!body.querySelector(".cb-intervention-btn") && !body.querySelector(".cb-badge")) {
        if (typeof onFirstMessage === "function") onFirstMessage();
      }
  
      scroll(body);
    }
  
    function addSystemMessage(body, text) {
      const d = document.createElement("div");
      d.style.cssText = "align-self:center;font-size:12px;color:#94a3b8;padding:4px 0;text-align:center";
      d.textContent = text;
      body.appendChild(d);
      scroll(body);
    }
  
    // ── Typing indicator ────────────────────────────────────────────────────────
    let typingEl = null;
  
    function showTyping(body) {
      if (typingEl) return;
      typingEl = document.createElement("div");
      typingEl.className = "cb-typing";
      typingEl.innerHTML = `<div class="cb-dot"></div><div class="cb-dot"></div><div class="cb-dot"></div>`;
      body.appendChild(typingEl);
      scroll(body);
    }
  
    function hideTyping() {
      if (typingEl) { typingEl.remove(); typingEl = null; }
    }
  
    // ── Badges ──────────────────────────────────────────────────────────────────
    function showBadge(body, text, colorClass, id) {
      if (body.querySelector(`#${id}`)) return;
      const d = document.createElement("div");
      d.className = `cb-badge ${colorClass}`;
      d.id = id;
      d.textContent = text;
      body.appendChild(d);
      scroll(body);
    }
  
    function removeBadge(body, id) {
      const el = body.querySelector(`#${id}`);
      if (el) el.remove();
    }

    function setResponderStatus(statusEl, text, tone = "neutral") {
      if (!statusEl) return;
      statusEl.textContent = text;
      statusEl.style.background = tone === "human" ? "#ecfdf5" : tone === "waiting" ? "#fff7ed" : "#f8fafc";
      statusEl.style.color = tone === "human" ? "#047857" : tone === "waiting" ? "#b45309" : "#64748b";
      statusEl.style.borderTop = "1px solid #e2e8f0";
    }
  
    function addInterventionButton(body, onClick) {
      const existing = body.querySelector(".cb-intervention-btn");
      if (existing) return existing;

      const btn = document.createElement("button");
      btn.className = "cb-intervention-btn";
      btn.textContent = "Hablar con un humano";
      btn.onclick = onClick;
      body.appendChild(btn);
      scroll(body);
      return btn;
    }
  
    // ── Utilitários ─────────────────────────────────────────────────────────────
    function scroll(body) { body.scrollTop = body.scrollHeight; }
    function time() { return new Date().toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" }); }
    function esc(t) {
      return String(t)
        .replace(/&/g, "&amp;").replace(/</g, "&lt;")
        .replace(/>/g, "&gt;").replace(/"/g, "&quot;");
    }
  
    // ── Pantallas ───────────────────────────────────────────────────────────────
    function showChat(screenForm, screenChat) {
      screenForm.style.display = "none";
      screenChat.style.display = "flex";
    }
  
    return {
      createHTML,
      addUserMessage,
      addBotMessage,
      addSystemMessage,
      showTyping,
      hideTyping,
      showBadge,
      removeBadge,
      setResponderStatus,
      addInterventionButton,
      showChat,
    };
  })();
